import type {BattleState,GameSettings} from '../core/types';
export type SoundCue='summon'|'dig'|'upgrade'|'legendary'|'goose'|'orange'|'sprinkler'|'lottery_tick'|'lottery_win'|'victory'|'defeat';
type Note={frequency:number;delay:number;duration:number;volume:number;type?:OscillatorType;slide?:number};
const defaults:GameSettings={musicVolume:.5,soundVolume:.75,showDamageNumbers:true};
const volume=(n:unknown,fallback:number)=>typeof n==='number'&&Number.isFinite(n)?Math.max(0,Math.min(1,n)):fallback;
const arpeggio=(frequencies:number[],duration=.18,step=.09):Note[]=>frequencies.map((frequency,i)=>({frequency,delay:i*step,duration,volume:.24,type:'sine'}));
const cues:Record<SoundCue,Note[]>={
  summon:[{frequency:1174.66,delay:0,duration:.3,volume:.2},{frequency:1760,delay:.07,duration:.35,volume:.13}],
  dig:[{frequency:160,slide:55,delay:0,duration:.12,volume:.32,type:'triangle'},{frequency:310,slide:95,delay:.06,duration:.09,volume:.16,type:'triangle'}],
  upgrade:arpeggio([523.25,659.25,783.99],.2,.065),
  legendary:[...arpeggio([523.25,659.25,783.99,1046.5],.7,0),...arpeggio([1318.51,1567.98,2093],.28,.11)],
  goose:[{frequency:520,slide:230,delay:0,duration:.18,volume:.2,type:'triangle'},{frequency:620,slide:260,delay:.2,duration:.22,volume:.22,type:'triangle'}],
  orange:[{frequency:420,slide:80,delay:0,duration:.26,volume:.24},{frequency:150,slide:310,delay:.16,duration:.15,volume:.18}],
  sprinkler:Array.from({length:7},(_,i)=>({frequency:400+i*170,slide:180+i*50,delay:i*.065,duration:.15,volume:.09,type:'triangle'})),
  lottery_tick:[{frequency:1046.5,delay:0,duration:.055,volume:.15}],
  lottery_win:arpeggio([523.25,659.25,783.99,1046.5,1318.51],.35,.075),
  victory:[...arpeggio([523.25,659.25,783.99,1046.5],.4,.12),...arpeggio([523.25,659.25,783.99],.75,.0).map(n=>({...n,delay:.5,volume:.14}))],
  defeat:arpeggio([392,349.23,293.66,261.63],.32,.16),
};

/** A gesture-unlocked, entirely local synthesizer. Core and storage never own audio. */
export class SoundManager {
  private settings:GameSettings;
  private context:AudioContext|null=null;
  private music:GainNode|null=null;
  private effects:GainNode|null=null;
  private unlocking:Promise<void>|null=null;
  private unlocked=false;
  private disposed=false;
  private ducked=false;
  private timer:ReturnType<typeof setInterval>|null=null;
  private melodyStep=0;
  private nextBeat=0;
  private readonly voices=new Map<OscillatorNode,GainNode>();
  private readonly seen=new Map<string,Set<number>>();
  private readonly visibility=()=>this.applyVolumes(true);
  constructor(settings:Partial<GameSettings>={}) {
    this.settings={musicVolume:volume(settings.musicVolume,.5),soundVolume:volume(settings.soundVolume,.75),showDamageNumbers:settings.showDamageNumbers??true};
    if(typeof document!=='undefined')document.addEventListener('visibilitychange',this.visibility);
  }
  unlock():Promise<void> {
    if(this.disposed)return Promise.resolve();
    if(this.unlocking)return this.unlocking;
    if(this.unlocked&&this.context?.state==='running')return Promise.resolve();
    this.unlocking=this.open().finally(()=>{this.unlocking=null;});return this.unlocking;
  }
  private async open():Promise<void> {
    try {
      if(!this.context){
        const Host=globalThis.AudioContext||(globalThis as unknown as {webkitAudioContext?:typeof AudioContext}).webkitAudioContext;
        if(!Host)return;
        this.context=new Host();
      }
      const context=this.context;
      await context.resume();
      if(this.disposed||context.state==='closed')return;
      if(context.state!=='running')return;
      // A tab or device can suspend an already unlocked context. Resume its
      // existing graph and scheduler; recreating them would layer the music.
      if(this.unlocked){this.applyVolumes();return;}
      this.music=context.createGain();this.effects=context.createGain();
      this.music.connect(context.destination);this.effects.connect(context.destination);
      this.unlocked=true;this.applyVolumes();this.nextBeat=context.currentTime+.025;this.scheduleMusic();
      if(this.timer===null)this.timer=setInterval(()=>this.scheduleMusic(),450);
    }catch{ /* Browser policy, missing hardware and failed resume are silent fallbacks. */ }
  }
  setSettings(settings:GameSettings):void {
    this.settings={musicVolume:volume(settings.musicVolume,defaults.musicVolume),soundVolume:volume(settings.soundVolume,defaults.soundVolume),showDamageNumbers:settings.showDamageNumbers};this.applyVolumes();
  }
  setDucked(ducked:boolean):void {if(this.ducked===ducked)return;this.ducked=ducked;this.applyVolumes(true);}
  private applyVolumes(soft=false):void {
    const c=this.context;if(!c||!this.music||!this.effects)return;
    const hidden=typeof document!=='undefined'&&document.hidden;
    try{
      const gain=this.music.gain,value=this.settings.musicVolume*.12*((this.ducked||hidden)? .15 : 1);
      gain.cancelScheduledValues(c.currentTime);
      if(soft)gain.setTargetAtTime(value,c.currentTime,.16);else gain.setValueAtTime(value,c.currentTime);
      this.effects.gain.setValueAtTime(this.settings.soundVolume*.5,c.currentTime);
    }catch{ /* A closing host may reject parameter writes. */ }
  }
  private scheduleMusic():void {
    const c=this.context;if(!this.unlocked||this.disposed||!c||c.state!=='running'||!this.music)return;
    // C/D/E/G/A only: a slow 16-beat wooden-key phrase, one scheduler per manager.
    const melody=[523.251,659.255,783.991,880,783.991,659.255,587.33,523.251,659.255,783.991,1046.502,880,783.991,659.255,587.33,523.251];
    const at=Math.max(c.currentTime+.015,this.nextBeat);this.nextBeat=at+.45;
    this.tone({frequency:melody[this.melodyStep++%melody.length],delay:0,duration:.34,volume:.32,type:this.melodyStep%2?'sine':'triangle'},this.music,at);
  }
  private tone(note:Note,bus:GainNode,at:number):void {
    const c=this.context;if(!c||this.disposed)return;
    let oscillator:OscillatorNode|undefined,envelope:GainNode|undefined;
    try{
      oscillator=c.createOscillator();envelope=c.createGain();
      oscillator.type=note.type||'sine';oscillator.frequency.setValueAtTime(note.frequency,at);
      if(note.slide)oscillator.frequency.exponentialRampToValueAtTime(note.slide,at+note.duration*.9);
      envelope.gain.setValueAtTime(.0001,at);envelope.gain.linearRampToValueAtTime(note.volume,at+.008);envelope.gain.exponentialRampToValueAtTime(.0001,at+note.duration);
      oscillator.connect(envelope);envelope.connect(bus);this.voices.set(oscillator,envelope);
      const voice=oscillator,output=envelope;
      voice.onended=()=>{voice.disconnect();output.disconnect();this.voices.delete(voice);};
      voice.start(at);voice.stop(at+note.duration+.015);
    }catch{try{oscillator?.disconnect();envelope?.disconnect();}catch{/* already closed */}}
  }
  play(cue:SoundCue):void {
    const c=this.context;if(!this.unlocked||this.disposed||!c||c.state!=='running'||!this.effects||this.settings.soundVolume===0)return;
    for(const note of cues[cue]||[])this.tone(note,this.effects,c.currentTime+.005+note.delay);
  }
  consumeBattle(state:BattleState):void {
    if(this.disposed)return;
    let ids=this.seen.get(state.id);if(!ids){ids=new Set();this.seen.set(state.id,ids);if(this.seen.size>8)this.seen.delete(this.seen.keys().next().value!);}
    for(const event of state.events){
      if(ids.has(event.id))continue;ids.add(event.id);
      if(event.type==='dash')this.play('goose');
      else if(event.type==='orange'&&(event.value??0)<0)this.play('orange');
      else if(event.type==='sprinkler')this.play('sprinkler');
      else if(event.type==='purge'&&event.effect!=='legendary')this.play('upgrade');
    }
  }
  dispose():void {
    if(this.disposed)return;this.disposed=true;this.unlocked=false;
    if(this.timer!==null){clearInterval(this.timer);this.timer=null;}
    if(typeof document!=='undefined')document.removeEventListener('visibilitychange',this.visibility);
    for(const [oscillator,gain] of this.voices){try{oscillator.onended=null;oscillator.stop();oscillator.disconnect();gain.disconnect();}catch{/* already ended */}}
    this.voices.clear();this.seen.clear();
    try{this.music?.disconnect();this.effects?.disconnect();}catch{/* host closing */}
    if(this.context){try{void this.context.close().catch(()=>{});}catch{/* unavailable host */}}
    this.context=null;this.music=null;this.effects=null;
  }
}
