export const WAVES = [
  { count:5, interval:3, hpScale:1, boss:null },
  { count:6, interval:2.8, hpScale:1.25, boss:null },
  { count:7, interval:2.6, hpScale:1.6, boss:null },
  { count:8, interval:2.4, hpScale:2, boss:'husky_wrecker' },
  { count:10, interval:2.2, hpScale:2.5, boss:'mega_roomba' },
  { count:11, interval:2, hpScale:3.1, boss:'dr_clippers' },
  { count:12, interval:1.9, hpScale:3.8, boss:null },
  { count:13, interval:1.8, hpScale:4.6, boss:'box_kraken' },
  { count:14, interval:1.7, hpScale:5.5, boss:'sad_rain_frog' },
  { count:16, interval:1.6, hpScale:6.5, boss:'king_skunk' },
] as const;
export const WAVE_DURATION = 36;
export const FIRST_WAVE_PREPARATION = 20;
