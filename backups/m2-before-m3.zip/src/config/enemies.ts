export interface EnemyDefinition { id:string; hp:number; speed:number; armor:number; boss:boolean; interval:number; color:string; maxBrokenTiles?:number }
export const ENEMIES: Record<string, EnemyDefinition> = {
  rat: {id:'rat',hp:24,speed:.38,armor:0,boss:false,interval:0,color:'#b9a3bc'},
  roach: {id:'roach',hp:20,speed:.54,armor:0,boss:false,interval:0,color:'#ae8570'},
  crab: {id:'crab',hp:52,speed:.30,armor:.2,boss:false,interval:0,color:'#e78374'},
  husky_wrecker: {id:'husky_wrecker',hp:600,speed:.22,armor:.05,boss:true,interval:24,maxBrokenTiles:2,color:'#879eab'},
  mega_roomba: {id:'mega_roomba',hp:1500,speed:.22,armor:.1,boss:true,interval:10,color:'#b4b8bd'},
  dr_clippers: {id:'dr_clippers',hp:2200,speed:.22,armor:.1,boss:true,interval:9,color:'#b49aba'},
  box_kraken: {id:'box_kraken',hp:2800,speed:.22,armor:.1,boss:true,interval:12,color:'#d6ab79'},
  sad_rain_frog: {id:'sad_rain_frog',hp:3200,speed:.22,armor:.1,boss:true,interval:12,color:'#8baec6'},
  king_skunk: {id:'king_skunk',hp:4000,speed:.22,armor:.15,boss:true,interval:10,color:'#929b91'},
};
export const BOSS_IDS = Object.values(ENEMIES).filter(e=>e.boss).map(e=>e.id);
export const FRAGMENTS = ['bamboo_blade','sardine_cannon','orange_wand','chill_shield'] as const;
