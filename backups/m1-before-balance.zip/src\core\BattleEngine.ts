import { GridSystem } from './GridSystem';
import { BEE_PRODUCTION, DRAW_POOL, ECONOMY, UNITS } from '../config/units';
import { HEROES } from '../config/heroes';
import { ENEMIES, FRAGMENTS } from '../config/enemies';
import { WAVES, WAVE_DURATION } from '../config/waves';
import { MergeSystem } from './MergeSystem';
import { OpponentAI } from './OpponentAI';
import { Random } from './Random';
import type { BattleState, CommandResult, Enemy, Point, Side, Unit, UnitLocation, VisualEvent } from './types';
export interface EngineOptions { seed?:number; autoWaves?:boolean; ai?:boolean }
let battleSequence=0;
export class BattleEngine {
  state:BattleState;
  private sequence=1;
  private random:Random;
  private opponent=new OpponentAI();
  constructor(public options:EngineOptions={}) {
    this.random=new Random(options.seed??Math.floor(Math.random()*0xffffffff));
    const side=()=>({food:ECONOMY.initialFood,oranges:3,shovels:2,kills:0,damage:0,loot:[],fog:0});
    this.state={id:`${Date.now()}-${++battleSequence}`,phase:'ready',time:0,wave:0,waveTime:0,nextSpawn:0,spawned:0,grid:GridSystem.create(),sides:{player:side(),ai:side()},units:[],enemies:[],events:[],result:null};
  }
  start():void {
    if(this.state.phase!=='ready')return;
    this.state.phase='playing';if(this.options.autoWaves!==false)this.beginWave(1);
  }
  tick(dt:number):void {
    if(!Number.isFinite(dt)||dt<=0||this.state.phase!=='playing')return;
    let remaining=Math.min(dt,600);
    while(remaining>1e-8&&this.state.phase==='playing'){
      const step=Math.min(.05,remaining);this.step(step);remaining-=step;
    }
  }
  pause(value=true):void { if(this.state.phase==='playing'||this.state.phase==='paused') this.state.phase=value?'paused':'playing'; }
  grant(kind:string,side:Side='player'):CommandResult {
    if(!this.actionAllowed())return {ok:false,key:'hint.paused'};
    if(!UNITS[kind]&&!HEROES[kind]) return {ok:false,key:'hint.invalid'};
    const slot=Array.from({length:5},(_,i)=>i).find(i=>!this.state.units.some(u=>u.side===side&&u.location.zone==='bench'&&u.location.slot===i));
    if(slot===undefined)return{ok:false,key:'hint.benchFull'};
    const id=this.sequence++;
    this.state.units.push({id,kind,side,level:1,location:{zone:'bench',slot},statuses:{},energy:0,cooldown:0,production:0,buffTime:0,empowered:0,animation:0});
    return {ok:true,key:'hint.granted',unitId:id};
  }
  summon(side:Side='player'):CommandResult {
    if(!this.actionAllowed())return{ok:false,key:'hint.paused'};
    if(this.state.units.filter(u=>u.side===side&&u.location.zone==='bench').length>=5)return{ok:false,key:'hint.benchFull'};
    if(this.state.sides[side].food<10)return{ok:false,key:'hint.noFood'};
    let roll=this.random.next()*100;
    const choice=DRAW_POOL.find(item=>(roll-=item.weight)<0)??DRAW_POOL[DRAW_POOL.length-1];
    const result=this.grant(choice.id,side);
    if(result.ok)this.state.sides[side].food-=10;return result;
  }
  move(id:number,target:UnitLocation):CommandResult {
    if(!this.actionAllowed())return{ok:false,key:'hint.paused'};
    const source=this.state.units.find(u=>u.id===id);
    if(!source)return{ok:false,key:'hint.invalid'};
    if(target.zone==='board'&&!GridSystem.owns(source.side,target.col,target.row))return{ok:false,key:'hint.enemyTerritory'};
    if(!GridSystem.canPlace(this.state,source.side,target))return{ok:false,key:'hint.invalidTile'};
    const occupant=this.state.units.find(u=>u.side===source.side&&this.sameLocation(u.location,target));
    if(occupant?.id===source.id)return{ok:true,key:'hint.selected',unitId:id};
    if(occupant){
      const outcome=MergeSystem.combine(source,occupant);
      if(outcome.unit){
        this.state.units=this.state.units.filter(u=>u.id!==source.id&&u.id!==occupant.id);
        this.state.units.push(outcome.unit);
        const position=this.unitPosition(outcome.unit);
        this.event({type:'purge',side:source.side,...position,textKey:'hint.purged',unitId:outcome.unit.id,duration:1.4});
        return{ok:true,key:outcome.key,unitId:outcome.unit.id};
      }
      if(outcome.swap){const from=source.location;source.location={...target};occupant.location={...from};source.animation=1;occupant.animation=1;}
      if(!outcome.ok)this.event({type:'bubble',side:source.side,...this.unitPosition(occupant),textKey:outcome.key,unitId:occupant.id,duration:1.6});
      return{ok:outcome.ok,key:outcome.key,unitId:id};
    }
    source.location={...target};source.animation=1;return{ok:true,key:'hint.deployed',unitId:id};
  }
  dig(col:number,row:number,side:Side='player'):CommandResult {
    if(!this.actionAllowed())return{ok:false,key:'hint.paused'};
    if(!GridSystem.owns(side,col,row))return{ok:false,key:'hint.enemyTerritory'};
    const tile=this.state.grid[row][col],cost=tile==='B'?2:1;
    if(tile!=='G'&&tile!=='B')return{ok:false,key:'hint.invalidTile'};
    if(this.state.sides[side].shovels<cost)return{ok:false,key:'hint.noShovels'};
    this.state.sides[side].shovels-=cost;this.state.grid[row][col]='O';
    this.event({type:'burst',side,col,row,duration:.6,color:'#8fbd75'});
    return{ok:true,key:tile==='B'?'hint.repaired':'hint.dig'};
  }
  spawnBoss(kind:string,side?:Side):CommandResult {
    if(!this.actionAllowed())return{ok:false,key:'hint.paused'};
    if(!ENEMIES[kind]?.boss)return{ok:false,key:'hint.invalid'};
    for(const defender of side?[side]:['player','ai'] as Side[]){this.spawnEnemy(kind,defender);}
    return{ok:true,key:'hint.boss'};
  }
  spawnEnemy(kind:string,side:Side,scale=1):Enemy {
    const config=ENEMIES[kind];if(!config)throw new Error('Unknown enemy');
    const p=GridSystem.pathPosition(side,0);
    const enemy:Enemy={id:this.sequence++,kind,side,boss:config.boss,hp:config.hp*scale,maxHp:config.hp*scale,progress:0,col:p.col,row:p.row,speed:config.speed,armor:config.armor,size:1,abilityCooldown:config.interval,stun:0,slow:0,slowFactor:1,burn:0,burnDps:0,poison:0,poisonDps:0,stolenBy:[],hitFlash:0};
    this.state.enemies.push(enemy);
    if(enemy.boss){
      this.event({type:'bubble',side,col:p.col,row:p.row,textKey:`boss.${kind}.bubble`,duration:2.2});
      if(['box_kraken','sad_rain_frog','king_skunk'].includes(kind))this.bossAbility(enemy);
    }
    return enemy;
  }
  adjustOranges(delta:number,side:Side='player'):void {
    if(!this.actionAllowed()||!Number.isFinite(delta))return;
    this.state.sides[side].oranges=Math.max(0,this.state.sides[side].oranges+Math.trunc(delta));
    this.event({type:'orange',side,col:side==='player'?7:0,row:side==='player'?9:0,value:delta,duration:1.2,textKey:delta<0?'hint.orangeLost':'hint.orangeAdded'});
    if(this.state.sides[side].oranges===0)this.finish(side==='player'?'ai':'player','oranges');
  }
  addFood(amount:number,side:Side='player'):void { if(this.actionAllowed()&&Number.isFinite(amount))this.state.sides[side].food=Math.max(0,this.state.sides[side].food+Math.trunc(amount)); }
  skipWave():void {
    if(!this.actionAllowed())return;
    // Skipping drops pending enemies without kill income or loot.
    this.state.enemies=[];
    if(this.state.wave>=10){this.finishByScore();return;}
    this.beginWave(Math.max(1,this.state.wave+1));
  }
  surrender():void { if(this.state.phase==='playing'||this.state.phase==='paused')this.finish('ai','surrender'); }
  private actionAllowed():boolean { return this.state.phase==='ready'||this.state.phase==='playing'; }
  private sameLocation(a:UnitLocation,b:UnitLocation):boolean {
    return a.zone==='bench'&&b.zone==='bench'?a.slot===b.slot:a.zone==='board'&&b.zone==='board'&&a.col===b.col&&a.row===b.row;
  }
  private unitPosition(unit:Unit):Point { return unit.location.zone==='board'?unit.location:{col:unit.location.slot+1.2,row:11.8}; }
  private event(event:Omit<VisualEvent,'id'|'age'>):void { this.state.events.push({...event,id:this.sequence++,age:0}); }
  private step(dt:number):void {
    this.state.time+=dt;
    this.state.events=this.state.events.filter(e=>(e.age+=dt)<e.duration);
    for(const side of ['player','ai'] as Side[])this.state.sides[side].fog=Math.max(0,this.state.sides[side].fog-dt);
    if(this.options.autoWaves!==false)this.updateWaves(dt);
    if(this.options.ai!==false)this.opponent.tick(this,dt);
    for(const unit of [...this.state.units]){
      for(const status of Object.keys(unit.statuses) as (keyof Unit['statuses'])[]){
        const left=(unit.statuses[status]??0)-dt;if(left<=0)delete unit.statuses[status];else unit.statuses[status]=left;
      }
      unit.animation=Math.max(0,unit.animation-dt*3);unit.buffTime=Math.max(0,unit.buffTime-dt);
      if(unit.location.zone!=='board')continue;
      if(unit.statuses.SEALED||unit.statuses.KNOCKDOWN||unit.statuses.CONFUSED)continue;
      if(unit.kind==='bee'){
        const production=BEE_PRODUCTION[Math.min(2,unit.level-1)];unit.production+=dt;
        while(unit.production+1e-8>=production.interval){unit.production-=production.interval;this.state.sides[unit.side].food+=production.amount;this.event({type:'bubble',side:unit.side,...unit.location,textKey:'hint.food',value:production.amount,duration:1});}
        continue;
      }
      const stats=this.stats(unit);
      unit.cooldown-=dt;
      if(unit.cooldown>1e-8)continue;
      const candidates=this.state.enemies.filter(e=>e.side===unit.side&&e.hp>0&&GridSystem.distance(unit.location as Point,e)<=stats.range).sort((a,b)=>b.progress-a.progress);
      if(!candidates.length){unit.cooldown=0;continue;}
      this.attack(unit,candidates[0],stats.damage);
      // Preserve the fractional overshoot so fixed steps never reduce the configured attack rate.
      unit.cooldown+=1/(stats.rate*(unit.statuses.WET ? .55 : 1)*(unit.buffTime>0?4:1));
      unit.animation=1;
      if(HEROES[unit.kind]){
        unit.energy++;
        const required=HEROES[unit.kind].charge*.9**(unit.level-1);
        if(unit.energy>=required){unit.energy=0;this.ultimate(unit,candidates[0],stats.damage);}
      }
    }
    for(const enemy of [...this.state.enemies]){
      if(enemy.hp<=0)continue;
      enemy.hitFlash=Math.max(0,enemy.hitFlash-dt);
      if(enemy.burn>0){this.hurt(enemy,enemy.burnDps*Math.min(dt,enemy.burn));enemy.burn=Math.max(0,enemy.burn-dt);}
      if(enemy.poison>0){this.hurt(enemy,enemy.poisonDps*Math.min(dt,enemy.poison));enemy.poison=Math.max(0,enemy.poison-dt);}
      if(enemy.hp<=0)continue;
      enemy.stun=Math.max(0,enemy.stun-dt);enemy.slow=Math.max(0,enemy.slow-dt);
      if(enemy.boss){enemy.abilityCooldown-=dt;if(enemy.abilityCooldown<=0){this.bossAbility(enemy);enemy.abilityCooldown=ENEMIES[enemy.kind].interval;}}
      if(enemy.stun<=0)enemy.progress+=enemy.speed*dt*(enemy.slow>0?enemy.slowFactor:1);
      Object.assign(enemy,GridSystem.pathPosition(enemy.side,enemy.progress));
      if(enemy.progress>=15){
        this.state.enemies=this.state.enemies.filter(e=>e.id!==enemy.id);
        this.adjustOranges(enemy.boss?-2:-1,enemy.side);
        if(this.state.phase==='finished')break;
      }
    }
    this.state.enemies=this.state.enemies.filter(e=>e.hp>0);
    if(this.options.autoWaves!==false&&this.state.wave===10&&this.state.spawned>=WAVES[9].count&&this.state.enemies.length===0&&this.state.phase==='playing')this.finishByScore();
  }
  private beginWave(wave:number):void {
    this.state.wave=wave;this.state.waveTime=0;this.state.nextSpawn=wave===1?7:1;this.state.spawned=0;
    for(const side of ['player','ai'] as Side[]){
      this.state.sides[side].food+=ECONOMY.waveIncome;
      if(wave%3===0)this.state.sides[side].shovels++;
    }
    this.event({type:'bubble',side:'player',col:3.5,row:4.5,textKey:'hint.wave',value:wave,duration:1.8});
    const boss=WAVES[wave-1]?.boss;if(boss)this.spawnBoss(boss);
  }
  private updateWaves(dt:number):void {
    if(!this.state.wave)return;
    this.state.waveTime+=dt;this.state.nextSpawn-=dt;
    const config=WAVES[this.state.wave-1];
    if(this.state.spawned<config.count&&this.state.nextSpawn<=0){
      const index=this.state.spawned,kind=this.state.wave<3?'rat':index%5===4?'crab':index%3===1?'roach':'rat';
      for(const side of ['player','ai'] as Side[])this.spawnEnemy(kind,side,config.hpScale);
      this.state.spawned++;this.state.nextSpawn=config.interval;
    }
    if(this.state.wave<10&&this.state.waveTime>=WAVE_DURATION)this.beginWave(this.state.wave+1);
  }
  private stats(unit:Unit):{damage:number;rate:number;range:number} {
    const hero=HEROES[unit.kind],base=hero??UNITS[unit.kind];
    return{damage:base.damage*(hero?1.6:1.65)**(unit.level-1),rate:base.rate*(hero?1:1+.12*(unit.level-1)),range:base.range};
  }
  private lane(side:Side):Enemy[] { return this.state.enemies.filter(e=>e.side===side&&e.hp>0); }
  private shot(unit:Unit,enemy:Enemy,color?:string):void {
    this.event({type:'projectile',side:unit.side,...this.unitPosition(unit),targetCol:enemy.col,targetRow:enemy.row,color:color??HEROES[unit.kind]?.color??UNITS[unit.kind]?.color,duration:.25,unitId:unit.id});
  }
  private hurt(enemy:Enemy,amount:number,unit?:Unit,critical=false):void {
    if(enemy.hp<=0||amount<=0)return;
    const damage=amount*(1-enemy.armor),actual=Math.min(enemy.hp,damage);enemy.hp-=damage;
    if(amount>=3)enemy.hitFlash=.14;
    this.state.sides[enemy.side].damage+=actual;
    if(amount>=3)this.event({type:'damage',side:enemy.side,col:enemy.col,row:enemy.row,value:Math.round(damage),color:critical?'#f16941':'#fff7da',duration:.65});
    if(enemy.hp<=0){
      const owner=this.state.sides[enemy.side];owner.kills++;
      if(enemy.boss){
        owner.food+=15;const count=1+Math.floor(this.random.next()*2);
        for(let i=0;i<count;i++)owner.loot.push(FRAGMENTS[Math.floor(this.random.next()*FRAGMENTS.length)]);
      }else if(this.random.next()<.25)owner.food+=2;
      if(unit?.kind==='doge_wick'&&this.random.next()<.5)owner.food+=2;
      this.event({type:'burst',side:enemy.side,col:enemy.col,row:enemy.row,duration:.5,color:enemy.boss?'#f9bd56':'#c4dec7'});
    }
  }
  private splash(unit:Unit,center:Point,radius:number,damage:number,critical=false):void {
    for(const enemy of this.lane(unit.side))if(GridSystem.distance(center,enemy)<=radius)this.hurt(enemy,damage,unit,critical);
  }
  private pierce(unit:Unit,target:Enemy,damage:number,max=3):void {
    const start=this.unitPosition(unit),dx=target.col-start.col,dy=target.row-start.row,len=Math.hypot(dx,dy)||1;
    const hits=this.lane(unit.side).filter(e=>{
      const x=e.col-start.col,y=e.row-start.row,along=(x*dx+y*dy)/len,across=Math.abs(x*dy-y*dx)/len;
      return along>=0&&along<=this.stats(unit).range+1&&across<.5;
    }).sort((a,b)=>GridSystem.distance(start,a)-GridSystem.distance(start,b)).slice(0,max);
    for(const e of hits)this.hurt(e,damage,unit);
  }
  private attack(unit:Unit,target:Enemy,damage:number):void {
    this.shot(unit,target);
    switch(unit.kind){
      case 'hedgehog':this.pierce(unit,target,damage);break;
      case 'corgi':this.hurt(target,damage,unit);for(const other of this.lane(unit.side))if(other.id!==target.id&&GridSystem.distance(target,other)<=.8)this.hurt(other,damage*.5,unit);break;
      case 'doge_wick':this.pierce(unit,target,damage*.5);this.shot(unit,target,'#f5dc89');this.pierce(unit,target,damage*.5);break;
      case 'puss_in_hat':
        if(unit.empowered>0){unit.empowered--;for(const other of this.lane(unit.side))if((Math.abs(other.col-target.col)<=.35||Math.abs(other.row-target.row)<=.35)&&GridSystem.distance(target,other)<=1.2)this.hurt(other,damage*2.2,unit,true);}
        else this.hurt(target,damage,unit);break;
      case 'rocket_coon':
        if(!target.stolenBy.includes(unit.id)){target.stolenBy.push(unit.id);if(this.random.next()<.2){this.state.sides[unit.side].food++;this.event({type:'bubble',side:unit.side,...this.unitPosition(unit),textKey:'hint.stolen',duration:1});}}
        this.hurt(target,damage,unit);break;
      default:this.hurt(target,damage,unit);
    }
  }
  private ultimate(unit:Unit,target:Enemy,damage:number):void {
    const position=this.unitPosition(unit),lane=this.lane(unit.side);
    this.event({type:'bubble',side:unit.side,...position,textKey:`ult.${unit.kind}`,duration:1.7,unitId:unit.id});
    this.event({type:'burst',side:unit.side,...position,color:HEROES[unit.kind].color,unitId:unit.id,duration:.7});
    switch(unit.kind){
      case 'kungfu_po':for(const e of lane)if(GridSystem.distance(position,e)<=2.2){this.hurt(e,damage*3.5,unit,true);e.stun=2;}break;
      case 'bamboo_mafia':
        for(let i=0;i<5;i++){const live=this.lane(unit.side);if(!live.length)break;const e=live[Math.floor(this.random.next()*live.length)];this.shot(unit,e,'#ee8d59');for(const hit of live)if(GridSystem.distance(e,hit)<=.85){this.hurt(hit,damage*1.5,unit,true);hit.burn=3;hit.burnDps=damage*.35;}}
        break;
      case 'zen_master':for(const e of lane)if(e.progress<=target.progress+.5){this.hurt(e,damage*2.8,unit,true);this.knockback(e,1.4);}break;
      case 'puss_in_hat':unit.empowered=4;break;
      case 'meowfia':unit.buffTime=2.5;unit.cooldown=.02;break;
      case 'purrcerer':
        for(const e of lane.sort((a,b)=>GridSystem.distance(target,a)-GridSystem.distance(target,b)).slice(0,6)){this.shot(unit,e,'#cab7ff');this.hurt(e,damage*2.4,unit,true);e.stun=.6;}break;
      case 'samurai_doge':
        for(const e of lane)if(GridSystem.distance(target,e)<=.65){this.hurt(e,damage*4.5,unit,true);if(!e.boss&&e.hp>0&&e.hp/e.maxHp<.25)this.hurt(e,e.hp/(1-e.armor)+1,unit,true);}break;
      case 'doge_wick':for(let i=0;i<3;i++){this.pierce(unit,target,damage*2.8,99);this.shot(unit,target,'#f5dc89');}break;
      case 'ronin_goose':for(let i=0;i<7;i++){const e=this.lane(unit.side).sort((a,b)=>GridSystem.distance(position,a)-GridSystem.distance(position,b))[0];if(e){this.hurt(e,damage*1.6,unit,true);this.shot(unit,e,'#f5d291');}}break;
      case 'ballin_rooster':
        for(const e of lane)if(GridSystem.distance(position,e)<=2.2)this.knockback(e,1);
        for(let i=0;i<8;i++){const live=this.lane(unit.side);if(!live.length)break;const e=live[i%live.length];this.shot(unit,e,'#fc9248');this.hurt(e,damage*2,unit,true);}break;
      case 'rocket_coon':this.splash(unit,target,1.4,damage*3.2,true);break;
      case 'pepe_king':for(const e of lane){e.slow=4;e.slowFactor=.6;e.poison=4;e.poisonDps=damage*.65;}break;
    }
  }
  private knockback(enemy:Enemy,amount:number):void { enemy.progress=Math.max(0,enemy.progress-amount);Object.assign(enemy,GridSystem.pathPosition(enemy.side,enemy.progress)); }
  private bossAbility(enemy:Enemy):void {
    const units=this.state.units.filter(u=>u.side===enemy.side&&u.location.zone==='board');
    switch(enemy.kind){
      case 'husky_wrecker':{
        const cells:Point[]=[];
        for(let row=0;row<10;row++)for(let col=0;col<8;col++)if(GridSystem.owns(enemy.side,col,row)&&this.state.grid[row][col]==='O'&&!units.some(u=>u.location.zone==='board'&&u.location.col===col&&u.location.row===row))cells.push({col,row});
        const cell=cells.sort((a,b)=>GridSystem.distance(enemy,a)-GridSystem.distance(enemy,b))[0];
        if(cell){this.state.grid[cell.row][cell.col]='B';this.event({type:'burst',side:enemy.side,...cell,color:'#bd9478',duration:1});}break;
      }
      case 'mega_roomba':{
        const victim=units.filter(u=>UNITS[u.kind]?.category==='basic'&&GridSystem.distance(this.unitPosition(u),enemy)<=1.2).sort((a,b)=>a.level-b.level||a.id-b.id)[0];
        if(victim){this.state.units=this.state.units.filter(u=>u.id!==victim.id);enemy.hp=Math.min(enemy.maxHp,enemy.hp+enemy.maxHp*.2);enemy.size*=1.15;}break;
      }
      case 'dr_clippers':for(const u of units.filter(u=>GridSystem.distance(this.unitPosition(u),enemy)<=2).sort((a,b)=>b.level-a.level).slice(0,2)){u.level=Math.max(1,u.level-1);u.statuses.MERGE_LOCK=5;u.animation=1;}break;
      case 'box_kraken':{
        const victim=units.sort((a,b)=>b.level-a.level||this.stats(b).damage-this.stats(a).damage)[0];
        if(victim)victim.statuses.SEALED=18;break;
      }
      case 'sad_rain_frog':for(const u of units)u.statuses.WET=18;break;
      case 'king_skunk':this.state.sides[enemy.side].fog=6;break;
    }
    this.event({type:'bubble',side:enemy.side,col:enemy.col,row:enemy.row,textKey:`boss.${enemy.kind}.bubble`,duration:1.5});
  }
  private finishByScore():void {
    const p=this.state.sides.player,a=this.state.sides.ai;
    const difference=p.oranges-a.oranges||p.kills-a.kills||p.damage-a.damage;
    this.finish(difference>=0?'player':'ai','waves');
  }
  private finish(winner:Side,reason:'oranges'|'waves'|'surrender'):void {
    if(this.state.result)return;
    const playerLoot=[...this.state.sides.player.loot],aiLoot=[...this.state.sides.ai.loot];
    this.state.result={winner,reason,loot:[...playerLoot,...aiLoot],playerLoot,aiLoot,coins:winner==='player'?30+this.state.sides.player.food:0,elapsed:this.state.time};this.state.phase='finished';
  }
}
