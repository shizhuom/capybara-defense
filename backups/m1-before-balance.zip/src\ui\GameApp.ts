import { BattleEngine } from '../core/BattleEngine';
import type { BattleState, CommandResult, Interaction, Unit, UnitLocation } from '../core/types';
import { UNITS, BEE_PRODUCTION, ECONOMY } from '../config/units';
import { HEROES } from '../config/heroes';
import { RECIPES } from '../config/recipes';
import { BOSS_IDS } from '../config/enemies';
import { STAGE } from '../config/maps';
import { WAVES } from '../config/waves';
import { StickerRenderer } from '../render/StickerRenderer';
import { getLanguage, onLanguageChange, setLanguage, t } from '../i18n/i18n';
import { awardBattle, emptyProfile, loadProfile, resetOwnStorage, saveProfile } from './storage';
import { capyIllustration, capyLogo, escapeHtml as esc, UNIT_ICONS } from './art';

type Hit = { kind: 'cell'; col: number; row: number } | { kind: 'bench'; slot: number } | { kind: 'shovel' };
type DialogKind = 'pause' | 'recipes' | 'result';
type Drag = { pointerId: number; start: { x: number; y: number }; point: { x: number; y: number }; id?: number; shovel: boolean; moved: boolean };
const tr = (key: string, vars?: Record<string, string | number>) => esc(t(key, vars));
const unitName = (kind: string) => t(`${HEROES[kind] ? 'hero' : 'unit'}.${kind}`);
const clock = (seconds: number) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
const icon = (kind: string) => `<span aria-hidden="true" class="pet-icon">${UNIT_ICONS[kind] ?? '🍊'}</span>`;

export class GameApp {
  engine: BattleEngine | null = null;
  profile = loadProfile();
  private canvas: HTMLCanvasElement;
  private renderer: StickerRenderer;
  private dialog: HTMLDialogElement;
  private dialogKind: DialogKind | null = null;
  private resumeAfterRecipe = false;
  private speed: 1 | 2 = 1;
  private selectedId?: number;
  private shovelSelected = false;
  private drag?: Drag;
  private completedId = '';
  private savedResult = true;
  private lastFrame = performance.now();
  private lastRefresh = 0;
  private inspectorStamp = '';
  private keyboardStamp = '';
  private toast?: { key: string; vars: Record<string, string | number>; error: boolean; until: number };

  constructor(private root: HTMLElement) {
    this.root.innerHTML = this.shell();
    this.canvas = this.element<HTMLCanvasElement>('battle-canvas');
    this.dialog = this.element<HTMLDialogElement>('game-dialog');
    this.renderer = new StickerRenderer(this.canvas);
    this.bindEvents();
    onLanguageChange(() => this.refresh(true));
    const narrow = matchMedia('(max-width: 1050px)');
    this.element<HTMLDetailsElement>('dev-tools').open = !narrow.matches;
    narrow.addEventListener('change', () => { this.element<HTMLDetailsElement>('dev-tools').open = !narrow.matches; });
    this.refresh(true);
    requestAnimationFrame(this.frame);
  }

  private element<T extends HTMLElement = HTMLElement>(id: string): T {
    return this.root.querySelector<T>(`#${id}`)!;
  }

  private shell(): string {
    return `<div class="page-shell">
      <header class="masthead">
        <a class="brand" href="#" data-action="brand" aria-label="${tr('app.title')}"><span class="brand-mark">${capyLogo}</span><span><strong data-i18n="app.title"></strong><small data-i18n="app.subtitle"></small></span></a>
        <div class="header-actions"><span class="edition" data-i18n="app.edition"></span><div class="language-switch" role="group" data-label="app.language"><button type="button" data-action="zh-CN">中</button><button type="button" data-action="en">EN</button></div></div>
      </header>
      <main class="game-layout">
        <aside class="sandbox-column">
          <details id="dev-tools" class="paper-card dev-panel" open>
            <summary><span class="eyebrow" data-i18n="dev.tag"></span><span class="dev-heading"><span aria-hidden="true">✳</span> <span data-i18n="dev.title"></span><span class="collapse-chevron" aria-hidden="true">⌄</span></span></summary>
            <div class="dev-content"><p class="muted" data-i18n="dev.subtitle"></p><div class="live-strip"><i></i><span id="dev-state"></span><b id="dev-wave"></b></div>
              <button type="button" class="button food-button" data-action="food" data-battle><span aria-hidden="true">🥫</span><span data-i18n="dev.addFood"></span></button>
              <p class="control-caption" data-i18n="dev.addFoodNote"></p>
              <div class="control-group"><label for="dev-unit" data-i18n="dev.unitLabel"></label><select id="dev-unit" data-battle></select><button type="button" class="button button-light" data-action="grant" data-battle data-i18n="dev.grant"></button></div>
              <div class="control-group"><label for="dev-boss" data-i18n="dev.bossLabel"></label><select id="dev-boss" data-battle></select><button type="button" class="button button-peach" data-action="boss" data-battle data-i18n="dev.boss"></button><p class="control-caption" data-i18n="dev.bossNote"></p></div>
              <div class="control-group"><span class="field-label" data-i18n="dev.oranges"></span><div class="button-row"><button type="button" class="button button-light" data-action="orange-minus" data-battle data-i18n="dev.orangeRemove"></button><button type="button" class="button button-light" data-action="orange-plus" data-battle data-i18n="dev.orangeAdd"></button></div></div>
              <button type="button" class="button button-light" data-action="skip" data-battle><span aria-hidden="true">↠</span> <span data-i18n="dev.skip"></span></button>
              <div class="speed-control"><span data-i18n="dev.speed"></span><div class="segmented"><button type="button" data-action="speed-1" data-battle>1×</button><button type="button" data-action="speed-2" data-battle>2×</button></div></div>
              <div class="dev-live" id="dev-live"></div><p class="control-caption" id="dev-tip"></p>
              <div class="reset-control"><button type="button" class="text-button" data-action="reset" data-i18n="dev.reset"></button><p class="control-caption" data-i18n="dev.resetNote"></p></div>
            </div>
          </details>
          <div class="side-note"><span aria-hidden="true">✿</span><p data-i18n="guide.survival"></p></div>
        </aside>
        <section class="center-column">
          <div class="stage menu-mode" id="stage">
            <canvas id="battle-canvas" width="640" height="1386" tabindex="0" role="img"></canvas>
            <section class="menu-screen" id="menu-screen"></section>
            <div class="battle-hud" id="battle-hud" hidden>
              <div class="hud-topline"><div><span class="map-eyebrow" data-i18n="hud.map"></span><strong id="hud-wave"></strong></div><button type="button" class="icon-button" data-action="pause" data-label="hud.pause" id="pause-button"><span aria-hidden="true">Ⅱ</span></button></div>
              <div class="hud-resource-row"><div class="food-pill"><span aria-hidden="true">🥫</span><strong id="food-value">30</strong><span data-i18n="hud.food"></span></div><span class="time-chip" id="battle-clock"></span><button type="button" class="speed-pill" data-action="speed" data-label="hud.speedLabel" id="hud-speed">1×</button></div>
            </div>
            <div class="battle-actions" id="battle-actions" hidden><button type="button" class="recipe-shortcut icon-button" data-action="recipes" data-label="recipe.open"><span aria-hidden="true">✦</span></button><button type="button" class="summon-button" data-action="summon" id="summon-button"><span aria-hidden="true" class="bell">♧</span><span><strong id="summon-title"></strong><small id="summon-note"></small></span><span aria-hidden="true">＋</span></button></div>
          </div>
          <p class="stage-caption" data-i18n="guide.controls"></p>
        </section>
        <aside class="journal-column">
          <section class="paper-card guide-card"><span class="eyebrow" data-i18n="menu.new"></span><h2 data-i18n="guide.title"></h2><ol class="how-to"><li><b>01</b><div><h3 data-i18n="guide.step1"></h3><p data-i18n="guide.step1Body"></p></div></li><li><b>02</b><div><h3 data-i18n="guide.step2"></h3><p data-i18n="guide.step2Body"></p></div></li><li><b>03</b><div><h3 data-i18n="guide.step3"></h3><p data-i18n="guide.step3Body"></p></div></li></ol><div class="tiny-recipe"><span>🐼</span><b>+</b><span>🎋</span><b>=</b><span class="legend-sticker">🐼<i>✦</i></span></div><button type="button" class="text-button recipe-link" data-action="recipes" data-i18n="recipe.open"></button></section>
          <section class="paper-card inspect-card"><h2 data-i18n="inspect.title"></h2><div id="inspector"></div></section>
          <div class="tip-note"><span aria-hidden="true">☂</span><p data-i18n="guide.tip"></p></div>
          <details class="paper-card keyboard-card"><summary data-i18n="keyboard.title"></summary><p class="muted" data-i18n="keyboard.help"></p><div id="keyboard-controls"></div></details>
        </aside>
      </main>
      <footer class="page-footer"><span aria-hidden="true">✿</span> <span data-i18n="app.footer"></span></footer>
      <div class="toast" id="toast" role="status" aria-live="polite" hidden></div>
      <dialog id="game-dialog" class="game-dialog"></dialog>
    </div>`;
  }

  start(): void {
    this.closeDialog(false);
    this.engine = new BattleEngine();
    this.engine.start();
    this.speed = 1;
    this.completedId = '';
    this.clearSelection();
    this.lastFrame = performance.now();
    this.refresh(true);
    this.canvas.focus({ preventScroll: true });
  }

  private menu(): void {
    this.closeDialog(false);
    this.engine = null;
    this.clearSelection();
    this.refresh(true);
    this.root.querySelector<HTMLButtonElement>('[data-action="start"]')?.focus({ preventScroll: true });
  }

  private frame = (now: number): void => {
    const dt = Math.min(Math.max((now - this.lastFrame) / 1000, 0), 0.06);
    this.lastFrame = now;
    if (this.engine) {
      this.engine.tick(dt * this.speed);
      const state = this.engine.state;
      if (this.selectedId && !state.units.some(unit => unit.id === this.selectedId && unit.side === 'player')) this.selectedId = undefined;
      if (state.phase === 'finished' && this.completedId !== state.id) this.finish(state);
      const interaction: Interaction = { selectedId: this.selectedId, shovel: this.shovelSelected };
      if (this.drag?.moved) {
        interaction.draggingId = this.drag.id;
        interaction.pointer = this.drag.point;
        interaction.shovel = this.drag.shovel;
        const hit = this.renderer.hitTest(this.drag.point.x, this.drag.point.y);
        if (hit?.kind === 'cell') interaction.hover = { col: hit.col, row: hit.row };
      }
      this.renderer.draw(state, state.time, interaction);
    }
    if (now - this.lastRefresh > 120) { this.refresh(); this.lastRefresh = now; }
    requestAnimationFrame(this.frame);
  };

  private finish(state: BattleState): void {
    this.completedId = state.id;
    this.clearSelection();
    if (state.result) {
      const award = awardBattle(this.profile, state.id, state.result);
      this.profile = award.profile;
      if (award.awarded) this.savedResult = saveProfile(this.profile);
    }
    this.showDialog('result');
    this.refresh(true);
  }

  private refresh(force = false): void {
    const state = this.engine?.state;
    const active = state?.phase === 'playing';
    if (force) {
      document.documentElement.lang = getLanguage();
      document.title = t('app.title');
      this.root.querySelectorAll<HTMLElement>('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n!); });
      this.root.querySelectorAll<HTMLElement>('[data-label]').forEach(el => { el.setAttribute('aria-label', t(el.dataset.label!)); });
      this.root.querySelectorAll<HTMLButtonElement>('.language-switch button').forEach(button => {
        const selected = button.dataset.action === getLanguage();
        button.classList.toggle('selected', selected);
        button.setAttribute('aria-pressed', String(selected));
      });
      this.canvas.setAttribute('aria-label', `${t('hud.map')}. ${t('guide.controls')} ${t('keyboard.help')}`);
      this.updateSelect('dev-unit', Object.keys(UNITS), id => unitName(id));
      this.updateSelect('dev-boss', BOSS_IDS, id => t(`boss.${id}`));
      this.renderMenu();
      this.inspectorStamp = '';
      this.keyboardStamp = '';
      if (this.dialogKind) this.renderDialog();
    }
    this.element('stage').classList.toggle('menu-mode', !state);
    this.element('menu-screen').hidden = !!state;
    this.element('battle-hud').hidden = !state;
    this.element('battle-actions').hidden = !state;
    this.canvas.hidden = !state;
    this.root.querySelectorAll<HTMLButtonElement | HTMLSelectElement>('[data-battle]').forEach(el => { el.disabled = !active; });
    this.element('dev-state').textContent = t(`hud.${!state ? 'preparing' : state.phase === 'ready' ? 'preparing' : state.phase}`);
    this.element('dev-wave').textContent = state ? `${Math.max(1, state.wave)} / ${WAVES.length}` : '✿';
    this.element('dev-tip').textContent = !state ? t('dev.startFirst') : t('hud.nextWave', { time: Math.floor(state.waveTime) });
    this.element('dev-live').textContent = state ? `${t('dev.units', { count: state.units.filter(unit => unit.side === 'player' && unit.location.zone === 'board').length })} · ${t('dev.enemies', { count: state.enemies.filter(enemy => enemy.side === 'player').length })}` : '';
    this.root.querySelectorAll<HTMLButtonElement>('[data-action^="speed-"]').forEach(button => { button.classList.toggle('selected', button.dataset.action === `speed-${this.speed}`); });
    this.element('hud-speed').textContent = `${this.speed}×`;
    this.element<HTMLButtonElement>('hud-speed').disabled = !active;
    this.element<HTMLButtonElement>('pause-button').disabled = state?.phase !== 'playing';
    if (state) {
      const player = state.sides.player;
      const full = state.units.filter(unit => unit.side === 'player' && unit.location.zone === 'bench').length >= ECONOMY.benchSize;
      this.element('hud-wave').textContent = t('hud.wave', { wave: Math.max(1, state.wave), total: WAVES.length });
      this.element('food-value').textContent = String(Math.floor(player.food));
      this.element('battle-clock').textContent = clock(state.time);
      this.element('battle-clock').setAttribute('aria-label', `${t('hud.time')} ${clock(state.time)}`);
      this.element('summon-title').textContent = t('hud.summon');
      this.element('summon-note').textContent = full ? t('hud.benchFull') : player.food < ECONOMY.summonCost ? t('hud.noFood', { count: Math.ceil(ECONOMY.summonCost - player.food) }) : t('hud.cost');
      // Full or low-food clicks explain why the action is unavailable, without spending anything.
      this.element<HTMLButtonElement>('summon-button').disabled = !active;
      this.element('summon-button').classList.toggle('unaffordable', full || player.food < ECONOMY.summonCost);
      this.element('summon-button').setAttribute('aria-label', `${t('hud.summon')}. ${this.element('summon-note').textContent}`);
    }
    // Keep the canvas fixed in the viewport while a pointer is captured. Replacing
    // a tall hero inspector with the short shovel card can otherwise clamp page
    // scroll and move the board underneath the finger before pointerup.
    if (!this.drag) {
      this.renderInspector();
      this.renderKeyboard();
    }
    const toast = this.element('toast');
    toast.hidden = !this.toast || performance.now() > this.toast.until;
    if (this.toast) {
      const message = t(this.toast.key, this.toast.vars);
      if (toast.textContent !== message) toast.textContent = message;
      toast.classList.toggle('toast-error', this.toast.error);
    }
  }

  private updateSelect(id: string, ids: readonly string[], label: (id: string) => string): void {
    const select = this.element<HTMLSelectElement>(id);
    const previous = select.value;
    select.innerHTML = ids.map(value => `<option value="${esc(value)}">${esc(label(value))}</option>`).join('');
    if (ids.includes(previous)) select.value = previous;
  }

  private renderMenu(): void {
    this.element('menu-screen').innerHTML = `<div class="menu-top"><span class="menu-chip"><i></i>${tr('menu.eyebrow')}</span><span class="doodle-star" aria-hidden="true">✳</span></div><h1>${tr('menu.title').replace(/\n/g, '<br>')}</h1><p class="menu-subtitle">${tr('menu.subtitle').replace(/\n/g, '<br>')}</p><div class="hero-illustration">${capyIllustration}<span class="illustration-caption">${tr('render.keepCalm')} ✦</span></div><button type="button" class="button start-button" data-action="start"><span>${tr('menu.start')}</span><span aria-hidden="true">↗</span></button><p class="duration">${tr('menu.duration')}</p><div class="menu-stats"><span><strong>${this.profile.coins}</strong><small>${tr('profile.coins')}</small></span><span><strong>${this.profile.wins}</strong><small>${tr('profile.wins')}</small></span><span><strong>${this.profile.fragments.length}</strong><small>${tr('profile.fragments')}</small></span></div><p class="profile-history">${tr('menu.record', { count: this.profile.matches })}</p><button type="button" class="text-button menu-recipe-link" data-action="recipes">${tr('menu.recipes')} <span aria-hidden="true">→</span></button>`;
  }

  private renderInspector(): void {
    const unit = this.engine?.state.units.find(item => item.id === this.selectedId && item.side === 'player');
    const stamp = JSON.stringify([getLanguage(), this.shovelSelected, unit?.id, unit?.level, unit?.location, unit && Object.entries(unit.statuses).map(([key, time]) => [key, Math.ceil(time ?? 0)]), unit?.energy, this.engine?.state.sides.player.shovels]);
    if (stamp === this.inspectorStamp) return;
    this.inspectorStamp = stamp;
    const target = this.element('inspector');
    if (this.shovelSelected) {
      target.innerHTML = `<div class="selected-pet"><span class="selected-icon" aria-hidden="true">⚒</span><div><span class="eyebrow">${tr('inspect.select')}</span><h3>${tr('inspect.shovel')}</h3></div></div><p>${tr('inspect.shovelBody')}</p><strong class="shovel-count">${tr('hud.shovel', { count: this.engine?.state.sides.player.shovels ?? 0 })}</strong><button type="button" class="text-button" data-action="clear">${tr('inspect.cancel')}</button>`;
      return;
    }
    if (!unit) { target.innerHTML = `<div class="empty-inspector"><span aria-hidden="true">☁</span><p>${tr('inspect.empty')}</p></div><p class="shovel-help">${tr('guide.shovel')}</p>`; return; }
    const hero = HEROES[unit.kind];
    const basic = UNITS[unit.kind];
    const definition = hero ?? basic;
    const charge = hero ? Math.ceil(hero.charge * .9 ** (unit.level - 1)) : 0;
    const recipe = RECIPES.find(item => item.hero === unit.kind);
    const related = RECIPES.filter(item => (item.parts as readonly string[]).includes(unit.kind));
    const damage = Math.round(definition.damage * (hero ? 1.6 : 1.65) ** (unit.level - 1));
    const statuses = Object.entries(unit.statuses).filter(([, duration]) => (duration ?? 0) > 0);
    const place = unit.location.zone === 'bench' ? t('inspect.bench', { slot: unit.location.slot + 1 }) : t('inspect.board', { col: unit.location.col + 1, row: unit.location.row + 1 });
    let description = '';
    if (hero) description = `<div class="skill-box"><span class="eyebrow">${tr('inspect.skill')}</span><h4>${tr(`skill.${unit.kind}`)}</h4><p>${tr(`skill.${unit.kind}.desc`, { charge })}</p><div class="energy-track"><i style="width:${Math.min(100, unit.energy / charge * 100)}%"></i></div><small>${tr('inspect.energy', { value: unit.energy, total: charge })}</small></div><p>${tr('inspect.feed')}</p><div class="ingredient-row">${recipe?.parts.map(part => `<span>${icon(part)}${esc(unitName(part))}</span>`).join('<b> / </b>') ?? ''}</div>`;
    else if (basic.category === 'component') description = `<p>${tr('inspect.combine')}</p><div class="related-recipes">${related.map(item => { const other = item.parts.find(part => part !== unit.kind)!; return `<div>${icon(other)}<span>${esc(unitName(other))}<small>→ ${tr(`hero.${item.hero}`)}</small></span></div>`; }).join('')}</div>${unit.kind === 'shiba' || unit.kind === 'hat_wizard' ? `<p class="tiny-warning">${tr('recipe.doge')}</p>` : ''}`;
    else if (unit.kind === 'bee') { const production = BEE_PRODUCTION[unit.level - 1]; description = `<p class="skill-box">${tr('inspect.bee', { time: production.interval, amount: production.amount })}</p>`; }
    else description = `<p>${tr('inspect.merge', { level: basic.maxLevel })}</p>`;
    target.innerHTML = `<div class="selected-pet"><span class="selected-icon">${icon(unit.kind)}</span><div><span class="eyebrow">${tr(hero ? 'inspect.hero' : basic.category === 'basic' ? 'inspect.basic' : 'inspect.component')}</span><h3>${esc(unitName(unit.kind))}</h3><b class="level-badge">${tr('inspect.level', { level: unit.level })}</b></div></div><div class="unit-stats"><span>${tr('inspect.damage', { value: damage })}</span><span>${tr('inspect.range', { value: definition.range })}</span></div><div class="status-list">${statuses.length ? statuses.map(([status, duration]) => `<span>${tr(`status.${status}`)} · ${tr('time.seconds', { value: Math.ceil(duration!) })}</span>`).join('') : `<span class="status-ok">${tr('inspect.noStatus')}</span>`}</div>${description}<p class="location-caption">${tr('inspect.location', { place })}</p><button type="button" class="text-button" data-action="clear">${tr('inspect.cancel')}</button>`;
  }

  private renderKeyboard(): void {
    const state = this.engine?.state;
    const stamp = JSON.stringify([getLanguage(), state?.phase, state?.grid, state?.units.filter(unit => unit.side === 'player').map(unit => [unit.id, unit.kind, unit.level, unit.location]), this.selectedId, this.shovelSelected, state?.sides.player.shovels]);
    if (stamp === this.keyboardStamp) return;
    this.keyboardStamp = stamp;
    const container = this.element('keyboard-controls');
    const oldFocus = document.activeElement instanceof HTMLElement && container.contains(document.activeElement) ? document.activeElement.dataset.target : undefined;
    if (!state) { container.innerHTML = `<p class="muted">${tr('dev.startFirst')}</p>`; return; }
    const disabled = state.phase === 'playing' ? '' : ' disabled';
    const nests = Array.from({ length: 5 }, (_, slot) => {
      const unit = this.unitAt({ kind: 'bench', slot });
      const name = unit ? `${unitName(unit.kind)} · ${t('inspect.level', { level: unit.level })}` : t('keyboard.empty');
      return `<button type="button" class="key-cell ${unit?.id === this.selectedId ? 'key-selected' : ''}" data-target="bench:${slot}" aria-label="${tr('keyboard.bench', { slot: slot + 1, name })}" title="${esc(name)}"${disabled}>${unit ? icon(unit.kind) : slot + 1}</button>`;
    }).join('');
    const cells: string[] = [];
    for (let row = 5; row < 10; row++) for (let col = 0; col < 8; col++) {
      const unit = this.unitAt({ kind: 'cell', col, row });
      const tile = state.grid[row][col];
      const name = unit ? `${unitName(unit.kind)} · ${t('inspect.level', { level: unit.level })}` : t(`tile.${tile}`);
      cells.push(`<button type="button" class="key-cell tile-${tile} ${unit?.id === this.selectedId ? 'key-selected' : ''}" data-target="cell:${col}:${row}" aria-label="${tr('keyboard.cell', { row: row + 1, col: col + 1, name })}" title="${esc(name)}"${disabled}>${unit ? icon(unit.kind) : tile === 'G' ? '·' : tile === 'O' ? '+' : tile === 'B' ? '×' : tile === 'C' ? '♨' : tile === 'S' ? '↗' : '—'}</button>`);
    }
    container.innerHTML = `<div class="keyboard-nests">${nests}</div><button type="button" class="button button-light keyboard-shovel ${this.shovelSelected ? 'key-selected' : ''}" data-target="shovel"${disabled}>${tr('hud.shovel', { count: state.sides.player.shovels })}</button><div class="keyboard-grid">${cells.join('')}</div>`;
    if (oldFocus) container.querySelector<HTMLButtonElement>(`[data-target="${oldFocus}"]`)?.focus({ preventScroll: true });
  }

  private lootMarkup(loot: string[]): string {
    if (!loot.length) return `<p class="loot-empty">${tr('loot.none')}</p>`;
    const counts = new Map<string, number>();
    loot.forEach(id => counts.set(id, (counts.get(id) ?? 0) + 1));
    return `<ul class="loot-list">${[...counts].map(([id, count]) => `<li><span aria-hidden="true">✦</span><span>${tr(`fragment.${id}`)}</span><b>×${count}</b></li>`).join('')}</ul>`;
  }

  private showDialog(kind: DialogKind): void {
    this.dialogKind = kind;
    this.renderDialog();
    if (!this.dialog.open) this.dialog.showModal();
  }

  private renderDialog(): void {
    const kind = this.dialogKind;
    this.dialog.classList.toggle('recipe-dialog', kind === 'recipes');
    this.dialog.setAttribute('aria-labelledby', 'dialog-title');
    if (kind === 'pause' && this.engine) {
      this.dialog.innerHTML = `<div class="dialog-decoration" aria-hidden="true">♨</div><span class="eyebrow">${tr('pause.eyebrow')}</span><h2 id="dialog-title">${tr('pause.title')}</h2><p class="dialog-subtitle">${tr('pause.subtitle')}</p><h3>${tr('pause.loot')}</h3><div class="loot-columns"><section><h4>${tr('loot.you')}</h4>${this.lootMarkup(this.engine.state.sides.player.loot)}</section><section><h4>${tr('loot.ai')}</h4>${this.lootMarkup(this.engine.state.sides.ai.loot)}</section></div><p class="dialog-rule">${tr('pause.rule')}</p><button type="button" class="button button-teal" data-action="resume" autofocus>${tr('pause.keep')}</button><button type="button" class="text-button surrender-button" data-action="surrender">${tr('pause.surrender')}</button>`;
    } else if (kind === 'recipes') {
      const rows = (start: number, end: number) => RECIPES.slice(start, end).map(recipe => `<article class="recipe-card"><div class="recipe-equation">${recipe.parts.map(part => `<span title="${esc(unitName(part))}">${icon(part)}<small>${esc(unitName(part))}</small></span>`).join('<b>＋</b>')}<b>→</b></div><h4>${tr(`hero.${recipe.hero}`)}</h4><p><strong>${tr(`skill.${recipe.hero}`)}</strong> · ${tr(`skill.${recipe.hero}.desc`, { charge: HEROES[recipe.hero].charge })}</p></article>`).join('');
      this.dialog.innerHTML = `<button type="button" class="dialog-close icon-button" data-action="close-recipes" aria-label="${tr('recipe.close')}">×</button><span class="eyebrow">✦ 8 + 4 ✦</span><h2 id="dialog-title">${tr('recipe.title')}</h2><p class="dialog-subtitle">${tr('recipe.subtitle')}</p><p class="recipe-note">${tr('recipe.note')}</p><h3>${tr('recipe.cross')}</h3><div class="recipe-grid">${rows(0, 8)}</div><h3>${tr('recipe.unique')}</h3><div class="recipe-grid">${rows(8, 12)}</div><p class="doge-note">🐕 + 🧙 · ${tr('recipe.doge')}</p><button type="button" class="button button-teal" data-action="close-recipes">${tr('recipe.close')}</button>`;
    } else if (kind === 'result' && this.engine?.state.result) {
      const result = this.engine.state.result;
      const won = result.winner === 'player';
      this.dialog.innerHTML = `<div class="result-sticker" aria-hidden="true">${won ? '🍊' : '☁'}</div><span class="eyebrow">${tr('result.time', { time: clock(result.elapsed) })}</span><h2 id="dialog-title">${tr(won ? 'result.win' : 'result.loss')}</h2><p class="dialog-subtitle">${tr(won ? 'result.winSub' : 'result.lossSub')}</p><p class="result-reason">${tr(`result.reason.${result.reason}`)}</p><div class="result-rewards"><span><b>+${won ? result.coins : 0}</b><small>${tr('profile.coins')}</small></span><span><b>+${won ? result.loot.length : 0}</b><small>${tr('profile.fragments')}</small></span></div><h3>${tr('result.pool')}</h3>${this.lootMarkup(result.loot)}<p class="save-note">${tr(this.savedResult ? 'result.awarded' : 'result.memory')}</p><button type="button" class="button button-teal" data-action="start" autofocus>${tr('result.again')}</button><button type="button" class="text-button back-menu" data-action="menu">${tr('result.menu')}</button>`;
    }
    if (kind) this.dialog.insertAdjacentHTML('afterbegin', `<div class="language-switch dialog-language" role="group" aria-label="${tr('app.language')}"><button type="button" data-action="zh-CN" class="${getLanguage() === 'zh-CN' ? 'selected' : ''}" aria-pressed="${getLanguage() === 'zh-CN'}">中</button><button type="button" data-action="en" class="${getLanguage() === 'en' ? 'selected' : ''}" aria-pressed="${getLanguage() === 'en'}">EN</button></div>`);
  }

  private closeDialog(resume: boolean): void {
    if (this.dialog.open) this.dialog.close();
    this.dialogKind = null;
    if (resume && this.engine?.state.phase === 'paused') this.engine.pause(false);
  }

  private pause(): void {
    if (this.engine?.state.phase !== 'playing') return;
    this.engine.pause(true);
    this.cancelDrag();
    this.showDialog('pause');
    this.refresh();
  }

  private notify(key: string, error = false, vars: Record<string, string | number> = {}): void {
    this.toast = { key, vars, error, until: performance.now() + (error ? 4200 : 2600) };
    this.refresh();
  }

  private apply(result: CommandResult): void {
    if (result.ok && result.unitId) {
      this.selectedId = result.unitId;
      this.shovelSelected = false;
    }
    this.notify(result.key, !result.ok);
  }

  private canInteract(): boolean { return this.engine?.state.phase === 'playing'; }

  private clearSelection(): void { this.selectedId = undefined; this.shovelSelected = false; this.cancelDrag(); }

  private unitAt(hit: Hit): Unit | undefined {
    return this.engine?.state.units.find(unit => unit.side === 'player' && (hit.kind === 'bench'
      ? unit.location.zone === 'bench' && unit.location.slot === hit.slot
      : hit.kind === 'cell' && unit.location.zone === 'board' && unit.location.col === hit.col && unit.location.row === hit.row));
  }

  private activate(hit: Hit): void {
    if (!this.canInteract() || !this.engine) return;
    if (hit.kind === 'shovel') {
      this.shovelSelected = !this.shovelSelected;
      this.selectedId = undefined;
      this.refresh();
      return;
    }
    if (this.shovelSelected) {
      if (hit.kind === 'cell') {
        this.apply(this.engine.dig(hit.col, hit.row));
        if (this.engine.state.sides.player.shovels === 0) this.shovelSelected = false;
      }
      this.refresh();
      return;
    }
    const target = this.unitAt(hit);
    if (this.selectedId && target?.id !== this.selectedId) {
      const location: UnitLocation = hit.kind === 'bench' ? { zone: 'bench', slot: hit.slot } : { zone: 'board', col: hit.col, row: hit.row };
      this.apply(this.engine.move(this.selectedId, location));
    } else if (target) {
      this.selectedId = target.id;
      this.notify('hint.selected', false, { name: unitName(target.kind) });
    } else if (hit.kind === 'cell' && hit.row < 5) this.notify('hint.enemyTerritory', true);
    this.refresh();
  }

  private point(event: PointerEvent): { x: number; y: number } {
    const bounds = this.canvas.getBoundingClientRect();
    return { x: (event.clientX - bounds.left) / bounds.width * STAGE.width, y: (event.clientY - bounds.top) / bounds.height * STAGE.height };
  }

  private cancelDrag(): void {
    const previous = this.drag;
    this.drag = undefined;
    if (previous && this.canvas?.hasPointerCapture(previous.pointerId)) this.canvas.releasePointerCapture(previous.pointerId);
  }

  private bindEvents(): void {
    this.root.addEventListener('click', event => {
      const element = (event.target as HTMLElement).closest<HTMLElement>('[data-action], [data-target]');
      if (!element || (element instanceof HTMLButtonElement && element.disabled)) return;
      event.preventDefault();
      if (element.dataset.target) {
        const [kind, first, second] = element.dataset.target.split(':');
        this.activate(kind === 'cell' ? { kind, col: Number(first), row: Number(second) } : kind === 'bench' ? { kind, slot: Number(first) } : { kind: 'shovel' });
        return;
      }
      this.action(element.dataset.action!);
    });
    this.canvas.addEventListener('pointerdown', event => {
      if (!this.canInteract() || !event.isPrimary || event.button !== 0) return;
      event.preventDefault();
      const point = this.point(event);
      const hit = this.renderer.hitTest(point.x, point.y);
      if (!hit) return;
      const unit = this.unitAt(hit);
      this.drag = { pointerId: event.pointerId, start: point, point, id: unit?.id, shovel: hit.kind === 'shovel', moved: false };
      this.canvas.setPointerCapture(event.pointerId);
    });
    this.canvas.addEventListener('pointermove', event => {
      if (!this.drag || this.drag.pointerId !== event.pointerId || !this.canInteract()) return;
      event.preventDefault();
      this.drag.point = this.point(event);
      if ((this.drag.id || this.drag.shovel) && Math.hypot(this.drag.point.x - this.drag.start.x, this.drag.point.y - this.drag.start.y) > 9) {
        this.drag.moved = true;
        this.selectedId = this.drag.id;
        this.shovelSelected = this.drag.shovel;
      }
    });
    this.canvas.addEventListener('pointerup', event => {
      const drag = this.drag;
      if (!drag || drag.pointerId !== event.pointerId) return;
      const point = this.point(event);
      const hit = this.renderer.hitTest(point.x, point.y);
      this.cancelDrag();
      if (!this.canInteract() || !hit) { this.refresh(); return; }
      if (drag.moved) {
        this.selectedId = drag.id;
        this.shovelSelected = drag.shovel;
        if (hit.kind !== 'shovel') this.activate(hit);
      } else this.activate(hit);
      this.refresh();
    });
    this.canvas.addEventListener('pointercancel', () => { this.cancelDrag(); this.refresh(); });
    this.canvas.addEventListener('lostpointercapture', () => { this.drag = undefined; });
    this.dialog.addEventListener('cancel', event => {
      event.preventDefault();
      if (this.dialogKind === 'pause') this.action('resume');
      else if (this.dialogKind === 'recipes') this.action('close-recipes');
      else this.menu();
    });
    document.addEventListener('keydown', event => {
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLSelectElement || event.target instanceof HTMLTextAreaElement) return;
      if (event.key === 'Escape' && !this.dialog.open) { this.clearSelection(); this.refresh(); }
      if (event.key.toLowerCase() === 'p' && !event.repeat && !this.dialog.open) this.pause();
      if (event.code === 'Space' && event.target === this.canvas && this.canInteract()) { event.preventDefault(); this.action('summon'); }
    });
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.pause(); });
  }

  private action(action: string): void {
    if (action === 'zh-CN' || action === 'en') { setLanguage(action); return; }
    if (action === 'brand') { if (this.canInteract()) this.pause(); return; }
    if (action === 'start') { this.start(); return; }
    if (action === 'menu') { this.menu(); return; }
    if (action === 'clear') { this.clearSelection(); this.refresh(); return; }
    if (action === 'pause') { this.pause(); return; }
    if (action === 'resume') { this.closeDialog(true); this.refresh(); this.canvas.focus({ preventScroll: true }); return; }
    if (action === 'recipes') {
      this.resumeAfterRecipe = this.canInteract();
      if (this.resumeAfterRecipe) this.engine!.pause(true);
      this.cancelDrag();
      this.showDialog('recipes');
      this.refresh();
      return;
    }
    if (action === 'close-recipes') { this.closeDialog(this.resumeAfterRecipe); this.resumeAfterRecipe = false; this.refresh(); return; }
    if (action === 'surrender') {
      if (this.engine?.state.phase === 'paused') { this.closeDialog(false); this.engine.surrender(); if (this.engine.state.result) this.finish(this.engine.state); }
      return;
    }
    if (action === 'reset') {
      const success = resetOwnStorage();
      this.profile = emptyProfile();
      this.menu();
      setLanguage('zh-CN');
      this.notify(success ? 'hint.reset' : 'hint.storage', !success);
      return;
    }
    if (!this.canInteract() || !this.engine) return;
    if (action === 'summon') this.apply(this.engine.summon());
    else if (action === 'food') { this.engine.addFood(500); this.notify('hint.foodAdded'); }
    else if (action === 'grant') this.apply(this.engine.grant(this.element<HTMLSelectElement>('dev-unit').value));
    else if (action === 'boss') this.apply(this.engine.spawnBoss(this.element<HTMLSelectElement>('dev-boss').value));
    else if (action === 'orange-plus' || action === 'orange-minus') { this.engine.adjustOranges(action === 'orange-plus' ? 1 : -1); this.notify(action === 'orange-plus' ? 'hint.orangeAdded' : 'hint.orangeLost'); }
    else if (action === 'skip') { this.engine.skipWave(); this.notify('hint.waveSkipped'); }
    else if (action === 'speed') this.speed = this.speed === 1 ? 2 : 1;
    else if (action === 'speed-1') this.speed = 1;
    else if (action === 'speed-2') this.speed = 2;
    this.refresh();
  }
}
