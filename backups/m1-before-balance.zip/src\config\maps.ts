import type { Point, Side, Tile } from '../core/types';
export const MAP = [
  'CGGGGGGS', 'RGGOOOGR', 'RGGOOOGR', 'RGGRRRRR', 'RRRRGGGG',
  'GGGGRRRR', 'RRRRRGGR', 'RGOOOGGR', 'RGOOOGGR', 'SGGGGGGC',
].map(row => row.split('') as Tile[]);
export const PATHS: Record<Side, Point[]> = {
  ai: [[7,0],[7,1],[7,2],[7,3],[6,3],[5,3],[4,3],[3,3],[3,4],[2,4],[1,4],[0,4],[0,3],[0,2],[0,1],[0,0]].map(([col,row])=>({col,row})),
  player: [[0,9],[0,8],[0,7],[0,6],[1,6],[2,6],[3,6],[4,6],[4,5],[5,5],[6,5],[7,5],[7,6],[7,7],[7,8],[7,9]].map(([col,row])=>({col,row})),
};
export const STAGE = { width: 640, height: 1386, cell: 72, boardX: 32, boardY: 240, benchY: 1120, benchX: 72, benchStep: 100, benchSize: 84, shovelX: 550, shovelY: 1035 };
