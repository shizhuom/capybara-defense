import { chromium } from 'playwright-core';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const temp=path.join(root,'.runtime','browser-tmp');fs.mkdirSync(temp,{recursive:true});
const executablePath=process.env.CAPY_CHROME??[
  path.join(process.env.PROGRAMFILES??'C:/Program Files','Google/Chrome/Application/chrome.exe'),
  path.join(process.env['PROGRAMFILES(X86)']??'C:/Program Files (x86)','Microsoft/Edge/Application/msedge.exe'),
].find(file=>fs.existsSync(file));
if(!executablePath)throw new Error('Set CAPY_CHROME to an installed Chrome/Edge executable.');
const browser=await chromium.launch({headless:true,executablePath,env:{...process.env,TEMP:temp,TMP:temp},args:['--disable-breakpad','--disable-crash-reporter']});
const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
try{
  await page.goto('http://127.0.0.1:4175/',{waitUntil:'networkidle'});
  assert.equal(await page.evaluate(()=>typeof window.__CAPY_DEBUG__),'undefined');
  await page.locator('[data-action="start"]').click();
  await page.locator('[data-action="food"]').click();
  assert.equal(await page.locator('#food-value').innerText(),'540');
  await page.locator('[data-action="summon"]').click();
  assert.equal(await page.locator('#food-value').innerText(),'530');
  await page.locator('[data-action="pause"]').click();
  assert.ok(await page.locator('#game-dialog').evaluate(e=>e.open));
  await page.locator('[data-action="surrender"]').click();
  await page.locator('#game-dialog [data-action="menu"]').click();
  await page.reload({waitUntil:'networkidle'});
  const saved=await page.evaluate(()=>JSON.parse(localStorage.getItem('capybara_defense_v1:profile')));
  assert.equal(saved.matches,1);assert.equal(saved.wins,0);assert.equal(saved.fragments.length,0);
  assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(root,'verification','production-smoke.json'),JSON.stringify({passed:true,errors,checks:['Built bundle loads without debug API','Actual summon and food controls work','Pause and surrender produce loss','Profile persists once after reload']},null,2));
  console.log('PASS production build, actual controls, pause/surrender, persistence, zero console errors');
}finally{await browser.close();}
