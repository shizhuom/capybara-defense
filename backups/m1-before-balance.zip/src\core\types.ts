export type Side = 'player' | 'ai';
export type Tile = 'C' | 'G' | 'O' | 'S' | 'R' | 'B';
export type Status = 'SEALED' | 'WET' | 'KNOCKDOWN' | 'CONFUSED' | 'MERGE_LOCK';
export interface Point { col: number; row: number }
export type UnitLocation = { zone: 'board'; col: number; row: number } | { zone: 'bench'; slot: number };
export interface Unit {
  id: number; kind: string; side: Side; level: number; location: UnitLocation;
  statuses: Partial<Record<Status, number>>; energy: number; cooldown: number;
  production: number; buffTime: number; empowered: number; animation: number;
}
export interface Enemy {
  id: number; kind: string; side: Side; boss: boolean; hp: number; maxHp: number;
  progress: number; col: number; row: number; speed: number; armor: number; size: number;
  abilityCooldown: number; stun: number; slow: number; slowFactor: number;
  burn: number; burnDps: number; poison: number; poisonDps: number; stolenBy: number[]; hitFlash: number;
}
export interface SideState { food: number; oranges: number; shovels: number; kills: number; damage: number; loot: string[]; fog: number }
export interface VisualEvent {
  id: number; type: 'projectile' | 'burst' | 'bubble' | 'damage' | 'purge' | 'orange';
  side: Side; col: number; row: number; targetCol?: number; targetRow?: number;
  textKey?: string; value?: number; color?: string; age: number; duration: number; unitId?: number;
}
export interface BattleResult { winner: Side; reason: 'oranges' | 'waves' | 'surrender'; loot: string[]; playerLoot: string[]; aiLoot: string[]; coins: number; elapsed: number }
export interface BattleState {
  id: string; phase: 'ready' | 'playing' | 'paused' | 'finished'; time: number;
  wave: number; waveTime: number; nextSpawn: number; spawned: number;
  grid: Tile[][]; sides: Record<Side, SideState>; units: Unit[]; enemies: Enemy[];
  events: VisualEvent[]; result: BattleResult | null;
}
export interface CommandResult { ok: boolean; key: string; unitId?: number }
export interface Profile { coins: number; wins: number; matches: number; fragments: string[]; awardedBattles: string[] }
export interface Interaction { draggingId?: number; pointer?: { x: number; y: number }; shovel?: boolean; hover?: Point; selectedId?: number }
