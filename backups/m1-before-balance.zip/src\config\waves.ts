export const WAVES = [
  { count:6, interval:2.8, hpScale:1, boss:null },
  { count:7, interval:2.5, hpScale:1.15, boss:'husky_wrecker' },
  { count:9, interval:2.2, hpScale:1.3, boss:null },
  { count:10, interval:2, hpScale:1.5, boss:'mega_roomba' },
  { count:11, interval:1.8, hpScale:1.75, boss:null },
  { count:12, interval:1.7, hpScale:2, boss:'dr_clippers' },
  { count:13, interval:1.6, hpScale:2.3, boss:null },
  { count:14, interval:1.5, hpScale:2.6, boss:'box_kraken' },
  { count:15, interval:1.4, hpScale:3, boss:'sad_rain_frog' },
  { count:18, interval:1.2, hpScale:3.5, boss:'king_skunk' },
] as const;
export const WAVE_DURATION = 28;
