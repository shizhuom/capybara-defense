import type { BattleEngine } from './BattleEngine';
import { MergeSystem } from './MergeSystem';
import { GridSystem } from './GridSystem';
import { PATHS } from '../config/maps';
import { HEROES } from '../config/heroes';
import { UNITS } from '../config/units';
/** The opponent spends the same resources and issues exactly the same legal commands. */
export class OpponentAI {
  private timer=.4;
  tick(engine:BattleEngine,dt:number):void {
    this.timer-=dt;if(this.timer>0)return;this.timer=.85;
    const {state}=engine,units=state.units.filter(u=>u.side==='ai');
    // Finish a recipe/feed even when the bench is full, before buying another card.
    for(const a of units)for(const b of units){
      if(a.id===b.id)continue;
      const result=MergeSystem.combine(a,b);
      if(result.unit){engine.move(a.id,b.location);return;}
    }
    const empty=[];
    for(let row=0;row<5;row++)for(let col=0;col<8;col++){
      if(state.grid[row][col]==='O'&&!units.some(u=>u.location.zone==='board'&&u.location.col===col&&u.location.row===row))empty.push({col,row});
    }
    empty.sort((a,b)=>Math.min(...PATHS.ai.map(p=>GridSystem.distance(p,a)))-Math.min(...PATHS.ai.map(p=>GridSystem.distance(p,b))));
    const bench=units.filter(u=>u.location.zone==='bench').sort((a,b)=>(HEROES[b.kind]?.damage??UNITS[b.kind]?.damage??0)-(HEROES[a.kind]?.damage??UNITS[a.kind]?.damage??0));
    if(bench.length&&empty.length){
      const location=bench[0].kind==='bee'?empty.at(-1)!:empty[0];
      engine.move(bench[0].id,{zone:'board',...location});return;
    }
    if(!empty.length&&state.sides.ai.shovels>0){
      const grass=[];
      for(let row=0;row<5;row++)for(let col=0;col<8;col++)if(state.grid[row][col]==='G')grass.push({col,row});
      grass.sort((a,b)=>Math.min(...PATHS.ai.map(p=>GridSystem.distance(p,a)))-Math.min(...PATHS.ai.map(p=>GridSystem.distance(p,b))));
      if(grass[0]){engine.dig(grass[0].col,grass[0].row,'ai');return;}
    }
    if(bench.length<5&&state.sides.ai.food>=10)engine.summon('ai');
  }
}
