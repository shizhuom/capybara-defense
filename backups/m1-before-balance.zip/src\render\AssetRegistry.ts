/** Optional local PNG overrides. Nothing is requested unless its id is in the manifest. */
export class AssetRegistry {
  private readonly images = new Map<string, HTMLImageElement>();
  readonly ready: Promise<void>;

  constructor(private readonly base = `${import.meta.env.BASE_URL || '/'}sprites/`) {
    this.ready = this.loadManifest();
  }

  get(id: string): HTMLImageElement | undefined {
    const image = this.images.get(id);
    return image?.complete && image.naturalWidth > 0 ? image : undefined;
  }

  private async loadManifest(): Promise<void> {
    if (typeof Image === 'undefined') return;
    try {
      const response = await fetch(`${this.base}manifest.json`);
      if (!response.ok) return;
      const manifest: unknown = await response.json();
      if (!Array.isArray(manifest)) return;
      await Promise.all(manifest.filter((id): id is string =>
        typeof id === 'string' && /^[a-z][a-z0-9_]*$/.test(id)
      ).map(id => new Promise<void>(resolve => {
        const image = new Image();
        image.onload = () => { this.images.set(id, image); resolve(); };
        image.onerror = () => resolve();
        image.src = `${this.base}${id}.png`;
      })));
    } catch {
      // Offline, malformed, or absent optional assets never prevent the game drawing.
    }
  }
}
