import { FRAGMENTS } from '../config/enemies';
import type { BattleResult, Profile } from '../core/types';

export const STORAGE_PREFIX = 'capybara_defense_v1:';
const validFragments = new Set<string>(FRAGMENTS);

export function browserStorage(): Storage | undefined {
  try { return typeof window === 'undefined' ? undefined : window.localStorage; }
  catch { return undefined; }
}

export function readSetting(key: string, storage = browserStorage()): string | null {
  try { return storage?.getItem(`${STORAGE_PREFIX}${key}`) ?? null; }
  catch { return null; }
}

export function writeSetting(key: string, value: string, storage = browserStorage()): boolean {
  try {
    if (!storage) return false;
    storage.setItem(`${STORAGE_PREFIX}${key}`, value);
    return true;
  } catch { return false; }
}

export function emptyProfile(): Profile {
  return { coins: 0, wins: 0, matches: 0, fragments: [], awardedBattles: [] };
}

const counter = (value: unknown): number =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 ? value : 0;

export function loadProfile(storage = browserStorage()): Profile {
  try {
    const raw: unknown = JSON.parse(readSetting('profile', storage) ?? 'null');
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return emptyProfile();
    const data = raw as Record<string, unknown>;
    const matches = counter(data.matches);
    return {
      coins: counter(data.coins), matches, wins: Math.min(counter(data.wins), matches),
      fragments: Array.isArray(data.fragments)
        ? data.fragments.filter((id): id is string => typeof id === 'string' && validFragments.has(id)) : [],
      awardedBattles: Array.isArray(data.awardedBattles)
        ? [...new Set(data.awardedBattles.filter((id): id is string => typeof id === 'string' && id.length > 0 && id.length < 200))] : [],
    };
  } catch { return emptyProfile(); }
}

export function saveProfile(profile: Profile, storage = browserStorage()): boolean {
  return writeSetting('profile', JSON.stringify(profile), storage);
}

/** A receipt and its rewards are saved together, so revisiting a result cannot pay twice. */
export function awardBattle(profile: Profile, battleId: string, result: BattleResult): { profile: Profile; awarded: boolean } {
  if (!battleId || profile.awardedBattles.includes(battleId)) return { profile, awarded: false };
  const won = result.winner === 'player';
  return {
    awarded: true,
    profile: {
      coins: profile.coins + (won ? counter(result.coins) : 0),
      wins: profile.wins + (won ? 1 : 0), matches: profile.matches + 1,
      fragments: [...profile.fragments, ...(won ? result.loot.filter(id => validFragments.has(id)) : [])],
      awardedBattles: [...profile.awardedBattles, battleId],
    },
  };
}

export function resetOwnStorage(storage = browserStorage()): boolean {
  try {
    if (!storage) return false;
    const ownKeys: string[] = [];
    for (let i = 0; i < storage.length; i++) {
      const key = storage.key(i);
      if (key?.startsWith(STORAGE_PREFIX)) ownKeys.push(key);
    }
    for (const key of ownKeys) storage.removeItem(key);
    return true;
  } catch { return false; }
}
