# Optional sticker artwork

The game ships with complete procedural Canvas artwork. No image download is required.

To override a character, place a transparent PNG here and list its bare id in `manifest.json`:

```json
["capybara", "hamster", "kungfu_po", "box_kraken"]
```

The files in this example are `capybara.png`, `hamster.png`, `kungfu_po.png`, and `box_kraken.png`. IDs use lowercase letters, digits, and underscores. Only listed IDs are requested; an absent or failed image falls back to the procedural sticker. Reload after changing the manifest. The game never loads remote art or fonts.

Use a square 256 × 256 or larger canvas, transparent background, generous clear margins, a thick warm charcoal outline, and an outer white sticker border. Center the character and its prop. The renderer preserves image aspect ratio and adds breathing, energy, level, status, and combat effects.

- Basic pets: `hamster`, `hedgehog`, `squirrel`, `corgi`, `bee`.
- Components: `panda`, `cat`, `shiba`, `hat_bamboo`, `hat_shades`, `hat_wizard`, `goose`, `cleaver`, `rooster`, `basketball`, `raccoon`, `trash_lid`, `frog`, `crown`.
- Heroes: `kungfu_po`, `bamboo_mafia`, `zen_master`, `puss_in_hat`, `meowfia`, `purrcerer`, `samurai_doge`, `doge_wick`, `ronin_goose`, `ballin_rooster`, `rocket_coon`, `pepe_king`.
- Enemies: `rat`, `roach`, `crab`.
- Bosses: `husky_wrecker`, `mega_roomba`, `dr_clippers`, `box_kraken`, `sad_rain_frog`, `king_skunk`.
- Guardian: `capybara`. Include the capybara **and its wooden bath tub**, but no oranges. The live orange stack is always drawn separately so life remains readable. Keep the top of the head near 23% of image height; the tub should reach 85%.

Keep the silhouette readable at 56 logical pixels. Large boss PNGs are drawn around 66–90 logical pixels. Art is cosmetic only: changing it does not alter range, movement, input targets, or game rules.
